package Source;

import board.Board;
import gui.SplashScreen;
import gui.Table;

public class Chess {
    
    public static void main(String[] args){
       Table table = new Table();
    }
}
