
package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class SplashScreen extends JPanel{
    private final JFrame splashScreen;
    private final  Dimension OUTER_FRAME_DIMENSION = new Dimension(900,700);
    
    public SplashScreen(){
        this.splashScreen = new JFrame("Chess");
        this.splashScreen.setLayout(new BorderLayout());
        this.splashScreen.setSize(OUTER_FRAME_DIMENSION);
        this.setVisible(true);
    }
}
